
from flask import Flask, render_template, request
import os
import subprocess
import openai
import shutil

app = Flask(__name__)
UPLOAD_FOLDER = "uploads"
OUTPUT_FOLDER = "output"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

openai.api_key = os.getenv("OPENAI_API_KEY")

def analyze_apk(apk_path):
    decompiled_path = os.path.join(OUTPUT_FOLDER, "decompiled")
    jadx_path = os.path.join(OUTPUT_FOLDER, "jadx")

    if os.path.exists(OUTPUT_FOLDER):
        shutil.rmtree(OUTPUT_FOLDER)
    os.makedirs(decompiled_path, exist_ok=True)
    os.makedirs(jadx_path, exist_ok=True)

    subprocess.run(["apktool", "d", apk_path, "-o", decompiled_path, "-f"], check=True)
    subprocess.run(["jadx", "-d", jadx_path, apk_path], check=True)

    manifest_path = os.path.join(decompiled_path, "AndroidManifest.xml")
    try:
        with open(manifest_path, 'r', encoding='utf-8') as f:
            manifest_raw = f.read()
            permissions = [line.strip() for line in manifest_raw.splitlines() if "android.permission" in line]
    except Exception as e:
        manifest_raw = ""
        permissions = [f"Error reading manifest: {e}"]

    prompt = f"""
You are a mobile security expert. Analyze this Android app based only on the permissions declared in its AndroidManifest.xml file.

Permissions:
{permissions}

Manifest content (truncated):
"""{manifest_raw[:1500]}..."""
"""

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are a mobile security analyst."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=1000,
            temperature=0.4
        )
        ai_report = response['choices'][0]['message']['content']
    except Exception as e:
        ai_report = f"OpenAI API error: {str(e)}"

    return permissions, ai_report

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        apk_file = request.files["apkfile"]

        if apk_file.filename == "":
            return "No APK file uploaded", 400

        apk_path = os.path.join(UPLOAD_FOLDER, apk_file.filename)
        apk_file.save(apk_path)

        permissions, ai_report = analyze_apk(apk_path)
        return render_template("result.html", permissions=permissions, ai_report=ai_report)

    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
